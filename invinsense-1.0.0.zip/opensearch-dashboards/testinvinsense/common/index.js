"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.PLUGIN_NAME = exports.PLUGIN_ID = void 0;
const PLUGIN_ID = 'Invinsense';
exports.PLUGIN_ID = PLUGIN_ID;
const PLUGIN_NAME = 'Invinsense';
exports.PLUGIN_NAME = PLUGIN_NAME;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sIm5hbWVzIjpbIlBMVUdJTl9JRCIsIlBMVUdJTl9OQU1FIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFBTyxNQUFNQSxTQUFTLEdBQUcsWUFBbEI7O0FBQ0EsTUFBTUMsV0FBVyxHQUFHLFlBQXBCIiwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGNvbnN0IFBMVUdJTl9JRCA9ICdJbnZpbnNlbnNlJztcclxuZXhwb3J0IGNvbnN0IFBMVUdJTl9OQU1FID0gJ0ludmluc2Vuc2UnO1xyXG4iXX0=