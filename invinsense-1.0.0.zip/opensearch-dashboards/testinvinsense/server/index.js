"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "TestinvinsensePluginSetup", {
  enumerable: true,
  get: function () {
    return _types.TestinvinsensePluginSetup;
  }
});
Object.defineProperty(exports, "TestinvinsensePluginStart", {
  enumerable: true,
  get: function () {
    return _types.TestinvinsensePluginStart;
  }
});
exports.plugin = plugin;

var _plugin = require("./plugin");

var _types = require("./types");

// This exports static code and TypeScript types,
// as well as, OpenSearch Dashboards Platform `plugin()` initializer.
function plugin(initializerContext) {
  return new _plugin.TestinvinsensePlugin(initializerContext);
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sIm5hbWVzIjpbInBsdWdpbiIsImluaXRpYWxpemVyQ29udGV4dCIsIlRlc3RpbnZpbnNlbnNlUGx1Z2luIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQ0E7O0FBU0E7O0FBUEE7QUFDQTtBQUVPLFNBQVNBLE1BQVQsQ0FBZ0JDLGtCQUFoQixFQUE4RDtBQUNuRSxTQUFPLElBQUlDLDRCQUFKLENBQXlCRCxrQkFBekIsQ0FBUDtBQUNEIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgUGx1Z2luSW5pdGlhbGl6ZXJDb250ZXh0IH0gZnJvbSAnLi4vLi4vLi4vc3JjL2NvcmUvc2VydmVyJztcclxuaW1wb3J0IHsgVGVzdGludmluc2Vuc2VQbHVnaW4gfSBmcm9tICcuL3BsdWdpbic7XHJcblxyXG4vLyBUaGlzIGV4cG9ydHMgc3RhdGljIGNvZGUgYW5kIFR5cGVTY3JpcHQgdHlwZXMsXHJcbi8vIGFzIHdlbGwgYXMsIE9wZW5TZWFyY2ggRGFzaGJvYXJkcyBQbGF0Zm9ybSBgcGx1Z2luKClgIGluaXRpYWxpemVyLlxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHBsdWdpbihpbml0aWFsaXplckNvbnRleHQ6IFBsdWdpbkluaXRpYWxpemVyQ29udGV4dCkge1xyXG4gIHJldHVybiBuZXcgVGVzdGludmluc2Vuc2VQbHVnaW4oaW5pdGlhbGl6ZXJDb250ZXh0KTtcclxufVxyXG5cclxuZXhwb3J0IHsgVGVzdGludmluc2Vuc2VQbHVnaW5TZXR1cCwgVGVzdGludmluc2Vuc2VQbHVnaW5TdGFydCB9IGZyb20gJy4vdHlwZXMnO1xyXG4iXX0=